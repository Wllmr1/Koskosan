async function sendMessage(){

  const input =
    document.getElementById("user-input");

  const message = input.value.trim();

  if(!message) return;

  addMessage(message,"user");

  input.value = "";

  showTyping();

  const response = await fetch(
    "http://localhost:3000/chat",
    {
      method:"POST",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        message
      })
    }
  );

  const data = await response.json();

  removeTyping();

  addMessage(data.reply,"bot");
}

function addMessage(text,sender){

  const chatBox =
    document.getElementById("chat-box");

  const div =
    document.createElement("div");

  div.classList.add("message");
  div.classList.add(sender);

  div.innerText = text;

  chatBox.appendChild(div);

  chatBox.scrollTop =
    chatBox.scrollHeight;
}

function quickMessage(text){

  document.getElementById("user-input").value = text;

  sendMessage();
}

function showTyping(){

  const chatBox =
    document.getElementById("chat-box");

  const typing =
    document.createElement("div");

  typing.classList.add("typing");

  typing.id = "typing";

  typing.innerText =
    "Restaurant is typing...";

  chatBox.appendChild(typing);

  chatBox.scrollTop =
    chatBox.scrollHeight;
}

function removeTyping(){

  const typing =
    document.getElementById("typing");

  if(typing){
    typing.remove();
  }
}

document
  .getElementById("user-input")
  .addEventListener("keypress",function(event){

    if(event.key === "Enter"){
      sendMessage();
    }

});

