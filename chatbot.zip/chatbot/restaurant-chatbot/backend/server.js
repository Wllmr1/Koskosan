const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.post("/chat", (req, res) => {

  const message =
    req.body.message.toLowerCase();

  let reply =
    "Sorry, I don't understand your request.";

  if(
    message.includes("hello") ||
    message.includes("hi") ||
    message.includes("halo")
  ){

    reply =
`Halo 👋
Welcome to Benny's Restaurant.

How can we help you today?`;
  }

  else if(message.includes("menu")){

    reply =
`🍔 BEST SELLER MENU

1. Wagyu Burger - Rp89k
2. Truffle Pasta - Rp99k
3. Chicken Steak - Rp75k
4. Matcha Latte - Rp35k
5. Fries - Rp29k`;
  }

  else if(message.includes("promo")){

    reply =
`🎉 TODAY PROMO

• Buy 1 Get 1 Matcha Latte
• 20% OFF for students
• Free fries for orders above Rp150k`;
  }

  else if(message.includes("reservation")){

    reply =
`📅 Reservation Format

Name:
Date:
Time:
Number of Guests:`;
  }

  else if(message.includes("delivery")){

    reply =
`🛵 Delivery Available

Available on:
• GrabFood
• GoFood
• ShopeeFood

Estimated delivery:
25-40 mins`;
  }

  else if(
    message.includes("location") ||
    message.includes("alamat")
  ){

    reply =
`📍 Location

PIK Avenue
Jakarta Utara`;
  }

  else if(
    message.includes("contact") ||
    message.includes("staff")
  ){

    reply =
`📞 Customer Service

+62 812-3456-7890`;
  }

  else if(
    message.includes("hours") ||
    message.includes("jam buka")
  ){

    reply =
`🕒 Opening Hours

Monday - Sunday
10:00 AM - 10:00 PM`;
  }

  res.json({ reply });
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
